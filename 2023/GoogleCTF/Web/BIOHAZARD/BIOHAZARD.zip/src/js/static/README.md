## Closure Library

Run the following commands from this directory.

```
git clone https://github.com/shhnjk/closure-library.git
cd closure-library
npm install
```

More details at https://developers.google.com/closure/library/docs/gettingstarted

