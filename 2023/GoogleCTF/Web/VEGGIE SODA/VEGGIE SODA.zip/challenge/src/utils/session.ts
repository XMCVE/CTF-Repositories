// @ts-ignore 
import { Session } from "https://deno.land/x/oak_sessions/mod.ts";

export type AppState = {
    session: Session
}