There are some actual example images on the challenge server, which are not distributed because all sort of issues.
