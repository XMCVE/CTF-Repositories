#!/bin/bash

cd $(dirname "$0")

./qemu-system-arm \
  -nographic \
  -serial chardev:serial0 \
  -serial /dev/null \
  -monitor /dev/null \
  -chardev stdio,signal=off,id=serial0 \
  -smp 2 \
  -machine virt,secure=on \
  -cpu cortex-a15 \
  -semihosting-config enable=on,target=native \
  -m 1057 \
  -bios bl1.bin \
  -object rng-random,filename=/dev/urandom,id=rng0 \
  -device virtio-rng-pci,rng=rng0,max-bytes=1024,period=1000 \
  -netdev user,id=vmnic,hostfwd=tcp::8889-:8889 \
  -device virtio-net-device,netdev=vmnic \
  -no-reboot

