export { App } from "./App.js";
